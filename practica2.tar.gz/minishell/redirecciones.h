#ifndef REDIRECCIONES_H
#define REDIRECCIONES_H

void redirec_entrada(char**, int, int*);
void redirec_salida(char**, int, int*);

#endif
