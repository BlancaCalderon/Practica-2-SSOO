#ifndef EJECUTAR_H
#define EJECUTAR_H

pid_t ejecutar_orden(const char*, int, int, int*);
void ejecutar_linea_ordenes(const char*);

#endif
