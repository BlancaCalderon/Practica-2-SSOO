#ifndef LIBMEMORIA_H
#define LIBMEMORIA_H

void free_argumentos(char **args);
void free_ordenes_pipes(char **ordenes, int **fds, int nordenes);

#endif 